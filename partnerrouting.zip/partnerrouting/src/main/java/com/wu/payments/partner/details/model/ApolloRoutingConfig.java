package com.wu.payments.partner.details.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "WUDPG_LOOKU_SETTLE_AGENT")
public class ApolloRoutingConfig {

    @Id
    Long ID;
    String SETTLEMENT_ID;
    String AGENT_ID;
    String COUNTERID;
    String FSID;
    String WAITTIMEINMINS;
    String CAPTUREEXPIRYTIMEINHRS;
    String ROUTING_ID;
    String REFUNDMETHOD;
    String EXPIRATIONTIMEINHOURS;
}
