package com.wu.payments.partner.details.service;

import com.wu.payments.partner.details.config.InitializeProcessorThrottling;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@Slf4j
public class GetProcessor {

    @Autowired
    InitializeProcessorThrottling ipt;

    public  String getProcessorFromMap(String throttlingName) {


        String processorName = null;
        try{
            Map<Integer,String> temp = ipt.getProcessorMap().get(throttlingName);
            log.info("temp: "+temp);
            InitializeProcessorThrottling.Token m_roundRobin = ipt.getTokenMap().get(throttlingName);
            if(null != m_roundRobin && null != temp){
                int current_count = m_roundRobin.next();
                log.info("current_count:"+current_count);
                for (Map.Entry<Integer, String> entry : temp.entrySet())
                {
                    if(current_count <= entry.getKey())
                    {
                        processorName = entry.getValue();
                        break;
                    }
                }
            }
        }
        catch (Exception e) {

            log.info("Exception caught in getProcessor"+e.getMessage());
        }
        return processorName;
    }
}
