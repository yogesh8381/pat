package com.wu.payments.partner.details.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class ApolloResponse {

    public String processor;
    public ApolloVendorCredentials vendorCredentials;
    public ApolloRoutingConfig routingConfig;
}
