package com.wu.payments.partner.details.repository;

import com.wu.payments.partner.details.utility.ProcessorThrottlingRowMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class ProcessorThrottlingRepo {

    private JdbcTemplate jdbdcTemplate;

    public ProcessorThrottlingRepo(JdbcTemplate jdbdcTemplate) {
        this.jdbdcTemplate = jdbdcTemplate;
    }

    public List<Map<String, String>> getprocessorThrottling() {
        String query = "select PAYMENTTYPE, PAYMENTSUBTYPE, COUNTRY, THROTTLING_PERCENTAGE, EXT_PROCESSOR, AMOUNT_THRESHOLD from Apollo_Throttling";

        log.info("Executing query to get processorTrottling details");
        List<Map<String, String>> apolloprocessorThrottlingList = jdbdcTemplate.query(query,
                new ProcessorThrottlingRowMapper());
        log.debug("Found {} records", apolloprocessorThrottlingList.size());
        return apolloprocessorThrottlingList;
    }
}
