package com.wu.payments.partner.details.service;

import com.wu.payments.partner.details.model.ApolloVendorCredentials;
import com.wu.payments.partner.details.repository.ApolloVendorCredRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class GetVendorCredentials {

    @Autowired
    ApolloVendorCredRepo avcrp;

    public ApolloVendorCredentials getVendorCred(String country, String paymentType, String paymentSubType, String extProcessor, String platform)
    {
        List<ApolloVendorCredentials> avc=avcrp.findByFilter(country,paymentType,paymentSubType,extProcessor,platform);
        ApolloVendorCredentials vc=new ApolloVendorCredentials();
        log.info("VendorCredentials Size"+avc.size());
        if (avc.size()==1)
        vc=avc.get(0);
        return vc;
    }
}
