package com.wu.payments.partner.details.controller;

import com.wu.payments.partner.details.model.ApolloRequest;
import com.wu.payments.partner.details.model.ApolloResponse;
import com.wu.payments.partner.details.model.ApolloRoutingConfig;
import com.wu.payments.partner.details.model.ApolloVendorCredentials;
import com.wu.payments.partner.details.service.GetProcessor;
import com.wu.payments.partner.details.service.GetVendorCredentials;
import com.wu.payments.partner.details.service.GetRoutingConfig;
import com.wu.payments.partner.details.constants.constant;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/payment")
@Slf4j
public class PartnerDetails {

    @Autowired
    GetProcessor gp;

    @Autowired
    GetVendorCredentials gvc;

    @Autowired
    GetRoutingConfig grc;

    @PostMapping("/getPartneDetails")
    public @ResponseBody Object getPartneDetails(@RequestBody ApolloRequest serviceRequest) throws Exception {

            String paymentType="";
            String paymentSubType="";
            String Country="";
            String Amount="";
            if(!( serviceRequest.getPaymentType() == null))
                 paymentType =serviceRequest.getPaymentType();
            if(!( serviceRequest.getPaymentSubType() == null ))
                paymentSubType =serviceRequest.getPaymentSubType();
            if(!( serviceRequest.getCountry() == null ))
                Country =serviceRequest.getCountry();
            if(!( serviceRequest.getAmount() == null ))
                Amount =serviceRequest.getAmount();
            System.out.println("paymentType--"+paymentType+"paymentSubType--"+paymentSubType+"Country--"+Country+"Amount--"+Amount);
        String throttlingName =(paymentType+paymentSubType+Country+Amount).toUpperCase();
       log.info("throttlingName"+throttlingName);
        String processor=gp.getProcessorFromMap(throttlingName);
        if (processor==null)
        {
            throttlingName =(paymentType+Country+Amount).toUpperCase();
            log.info("throttlingName"+throttlingName);
            processor=gp.getProcessorFromMap(throttlingName);
        }
            //if(( serviceRequest.getPaymentSubType() == null ))
              //  paymentSubType="ALL";
            String platformCheck=serviceRequest.getPlatform();
            List<String> valuesList = Arrays.asList(constant.platformCheck.split(","));
            String platform=null;
            if (valuesList.contains(platformCheck)) {
                platform=platformCheck+"_"+serviceRequest.getCurrency();
            } else {
                platform="ALL";
            }
            System.out.println("paymentType--"+paymentType+"paymentSubType--"+paymentSubType+"Country--"+Country+"processor--"+processor+"platform--"+platform);
        ApolloVendorCredentials avc= gvc.getVendorCred(Country,paymentType,paymentSubType,processor,platform);
        if (avc == null)
        {
            avc= gvc.getVendorCred(Country,paymentType,"ALL",processor,platform);
        }
        String PartnerId=serviceRequest.partnerId;
        ApolloRoutingConfig rconfig=grc.getApolloRoutingConfig(processor,Country,serviceRequest.currency,paymentType,paymentSubType,PartnerId);
        return new ApolloResponse(processor,avc,rconfig);
    }
}
