package com.wu.payments.partner.details.repository;

import com.wu.payments.partner.details.model.ApolloVendorCredentials;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApolloVendorCredRepo extends JpaRepository <ApolloVendorCredentials,Long> {

    String query="SELECT ID,COUNTRY,EXTPROCESSOR,MERCHANTID,PASSPHRASE,PAYMENTSUBTYPE,PAYMENTTYPE,\n" +
            "PLATFORM,PRIVATEKEY,PUBLICKEY,PUBLICKEYNAME,SECONDARYUSERACCOUNT,USERACCOUNT,USERID FROM APOLLO_VENDORCREDENTIALS where\n" +
            "COUNTRY=:country and PAYMENTTYPE=:paymentType and PAYMENTSUBTYPE=:paymentSubType and EXTPROCESSOR=:extProcessor and PLATFORM=:platform";
    @Query(value = query, nativeQuery = true)
    List<ApolloVendorCredentials> findByFilter(@Param("country") String country, @Param("paymentType") String paymentType, @Param("paymentSubType") String paymentSubType, @Param("extProcessor") String extProcessor, @Param("platform") String platform);
}
