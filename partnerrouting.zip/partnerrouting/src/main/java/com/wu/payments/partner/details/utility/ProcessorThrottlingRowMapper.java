package com.wu.payments.partner.details.utility;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class ProcessorThrottlingRowMapper implements RowMapper<Map<String, String>> {


    @Override
    public Map<String, String> mapRow(ResultSet rs, int rowNum) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();
        Map<String, String> resultsMap = new HashMap<>();

        for (int i = 1; i <= columnCount; ++i) {
            String columnName = metaData.getColumnName(i);
            String colVal = rs.getString(i);
            resultsMap.put(columnName, colVal);
        }

        return resultsMap;
    }
}
