package com.wu.payments.partner.details.repository;

import com.wu.payments.partner.details.model.ApolloRoutingConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ApolloRoutingConfigRepo extends JpaRepository<ApolloRoutingConfig,Long> {

    String query="select ID,SETTLEMENT_ID,AGENT_ID,COUNTERID,FSID,WAITTIMEINMINS,CAPTUREEXPIRYTIMEINHRS,ROUTING_ID,REFUNDMETHOD,EXPIRATIONTIMEINHOURS from WUDPG_LOOKU_SETTLE_AGENT WHERE ROUTING_ID=:routingId";
    @Query(value = query, nativeQuery = true)
    List<ApolloRoutingConfig> findByRoutingId(@Param("routingId") String routingId);

}
