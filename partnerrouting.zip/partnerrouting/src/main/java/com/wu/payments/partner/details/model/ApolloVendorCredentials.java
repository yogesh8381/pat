package com.wu.payments.partner.details.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "APOLLO_VENDORCREDENTIALS")
public class ApolloVendorCredentials {

    @Id
    Long ID;
    String COUNTRY;
    String EXTPROCESSOR;
    String MERCHANTID;
    String PASSPHRASE;
    String PAYMENTSUBTYPE;
    String PAYMENTTYPE;
    String PLATFORM;
    String PRIVATEKEY;
    String PUBLICKEY;
    String PUBLICKEYNAME;
    String SECONDARYUSERACCOUNT;
    String USERACCOUNT;
    String USERID;
}
