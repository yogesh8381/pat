package com.wu.payments.partner.details.constants;

public class constant {

    public static final String platformCheck=",PROJECTX,WUSHOPVIP,CLOVER,KIOSK,CLOUD,";
}
