package com.wu.payments.partner.details.service;

import com.wu.payments.partner.details.model.ApolloRoutingConfig;
import com.wu.payments.partner.details.repository.ApolloRoutingConfigRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class GetRoutingConfig {

    @Autowired
    ApolloRoutingConfigRepo arcr;

    public ApolloRoutingConfig getApolloRoutingConfig(String extProcessor, String billingCountry, String currency, String paymentType, String paymentSubType, String partnerID) {
        String agentId = formAgentId(extProcessor, billingCountry, currency, paymentType, paymentSubType, partnerID);
        List<ApolloRoutingConfig> RoutingConfigList = arcr.findByRoutingId(agentId);
        log.info("RoutingConfigList size" + RoutingConfigList.size());
        ApolloRoutingConfig routingConfig = new ApolloRoutingConfig();
        if (RoutingConfigList.size() == 1) {
            routingConfig = RoutingConfigList.get(0);
        }
        return routingConfig;
    }

    public String formAgentId(String extProcessor, String billingCountry, String currency, String paymentType, String paymentSubType, String partnerID) {
        log.debug("Value for partnerID ;" + partnerID);
        String RoutingId="";
        if (partnerID != null && (partnerID != "null" || partnerID != "")) {
            log.debug("Agent KEY Formed : CONFIG_" + billingCountry + "_" + currency + "_" + paymentType + "_" + paymentSubType + "_" + partnerID + "_" + extProcessor);
            RoutingId="CONFIG_" + billingCountry + "_" + currency + "_" + paymentType + "_" + paymentSubType + "_" + partnerID + "_" + extProcessor;
        }
        return RoutingId;
    }
}
