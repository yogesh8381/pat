package com.wu.payments.partner.details.config;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.wu.payments.partner.details.repository.ProcessorThrottlingRepo;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@Slf4j
public class InitializeProcessorThrottling {

    @Autowired
    private ProcessorThrottlingRepo repo;

    private Map<String, Map<Integer, String>> processorBucketedMap = new HashMap<String, Map<Integer, String>>();
    private Map<String ,String> processorAmountMap = new HashMap<>();
    private Map<String, Token> tokenMap = new TreeMap<String, Token>();
    private Map<String, Map<Integer, String>> tempMap;

    @PostConstruct
    public void init() {
        Map<String, String> processorMap = new HashMap<>();
        try{
        log.info("In init");
        List<Map<String, String>> apollo_throttlingDataDB = repo.getprocessorThrottling();
        int throttlingDataCount = apollo_throttlingDataDB.size();
        log.info("throttlingDataCount" + throttlingDataCount);
        if (throttlingDataCount > 0) {
            String paymentTypeDB = "";
            String paymentSubTypeDB = "";
            String countryDB = "";
            String amountThreshold = "";
            String percentage = "";

            for (int i = 0; i < throttlingDataCount; i++) {
                    paymentTypeDB = "";
                    paymentSubTypeDB = "";
                    countryDB = "";
                    amountThreshold = "";
                    percentage = "";
                    if (!isEmpty(apollo_throttlingDataDB.get(i).get("PAYMENTTYPE")))
                        paymentTypeDB = apollo_throttlingDataDB.get(i).get("PAYMENTTYPE");
                    if (!isEmpty(apollo_throttlingDataDB.get(i).get("PAYMENTSUBTYPE")))
                        paymentSubTypeDB = apollo_throttlingDataDB.get(i).get("PAYMENTSUBTYPE");
                    if (!isEmpty(apollo_throttlingDataDB.get(i).get("COUNTRY")))
                        countryDB = apollo_throttlingDataDB.get(i).get("COUNTRY");
                    amountThreshold = apollo_throttlingDataDB.get(i).get("AMOUNT_THRESHOLD");
                    percentage = apollo_throttlingDataDB.get(i).get("THROTTLING_PERCENTAGE");
                    String throttlingName = (paymentTypeDB + paymentSubTypeDB + countryDB + amountThreshold).toUpperCase();
                    String amtThrottlingName = (paymentTypeDB + paymentSubTypeDB + countryDB).toUpperCase();
                    log.info("ThrottlingName : " + throttlingName);
                    log.info("AmtThrottlingName : " + amtThrottlingName);
                    log.info("paymentTypeDB--" + paymentTypeDB + "paymentSubTypeDB--" + "countryDB--" + countryDB + "processoe--" + apollo_throttlingDataDB.get(i).get("EXT_PROCESSOR") + "percentage--" + percentage);
                    if (processorMap.containsKey(throttlingName)) {
                        String throttlingConfig = processorMap.get(throttlingName);
                        throttlingConfig = throttlingConfig + "," + percentage + "@" + apollo_throttlingDataDB.get(i).get("EXT_PROCESSOR");
                        processorMap.put(throttlingName, throttlingConfig);
                        log.info("appeneded config value for: " + throttlingName + " value : " + throttlingConfig);
                    } else {
                        String throttlingConfig = processorMap.get(throttlingName);
                        throttlingConfig = percentage + "@" + apollo_throttlingDataDB.get(i).get("EXT_PROCESSOR");
                        log.info("created config value for: " + throttlingName + " value : " + throttlingConfig);
                        processorMap.put(throttlingName, throttlingConfig);
                    }
                    if (processorAmountMap.containsKey(amtThrottlingName)) {
                        String throttlingConfig = processorAmountMap.get(amtThrottlingName) + "," + amountThreshold;
                        processorAmountMap.put(amtThrottlingName, throttlingConfig);
                        log.info("appeneded config value for: " + amtThrottlingName + " value : " + throttlingConfig);
                    } else {
                        processorAmountMap.put(amtThrottlingName, amountThreshold);
                        log.info("created config value for: " + amtThrottlingName + " value : " + amountThreshold);
                    }
                    log.info("Map Size :" + processorMap.size());
                    log.info("processorMap" + processorMap);
                }
            }
    }catch(Exception e)
        {
               e.printStackTrace();
        }

        createBucketedProcessorMap(processorMap);
        }
    public String enrichTokenAmount(Double amt)
    {
        String amount = String.valueOf(amt);
        if (amount.contains("."))
        {
            int indx=amount.indexOf(".");
            amount=amount.substring(0,indx);
        }
        return amount;
    }
    public boolean isEmpty(String str) {
        return str == null || str.isEmpty();
    }
    void createBucketedProcessorMap(Map<String, String> processorMap)
    {
        log.info("Dropping current map ...");
        tempMap=new HashMap<String, Map<Integer, String>>(processorBucketedMap);
        log.info("tempMap"+tempMap);
        processorBucketedMap.clear();
        try{
            for (Map.Entry<String, String> entry : processorMap.entrySet()) {
                log.info("entry"+entry);
                log.info("entry.getKey()"+entry.getKey());
                List<String> tempList = new ArrayList<String>();
                tempList = Arrays.asList(processorMap.get(entry.getKey()).split(","));
                log.info("tempList"+tempList);
                for(int i=0; i<tempList.size(); i++)
                {
                    String[] tmp = tempList.get(i).split("@");
                    for(int k=0;k< tmp.length;k++) {
                        log.info("tmpk"+tmp[k]);
                    }
                    if(1 == tmp[0].length())
                    {
                        log.info(tmp[0]+"---"+tmp[1]);
                        String temp = "0"+tmp[0]+"@"+tmp[1];
                        tempList.set(i, temp);
                    }
                }
                Collections.sort(tempList, Collections.reverseOrder());
                log.info("tlista"+tempList);
                creatingMap(tempList, entry.getKey());
                log.info("processorBucketedMap"+processorBucketedMap);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            log.info("ALERT: Fatal Exception. Trying to restore previous configuration...");
            if (!tempMap.isEmpty()){
                processorBucketedMap=new HashMap<String, Map<Integer, String>>(tempMap);
                log.info("ALERT: previous configuration restored...");
            }else {
                log.info("ALERT: Fatal Exception. Loading failed");
                throw new RuntimeException();
            }
        }
    }
    void creatingMap(List<String> tempList, String trottlingName)throws Exception {
        int count = 0;
        int[] arr = new int[tempList.size()];

        log.info("tempList"+tempList);
        //try{

        // calculating bucket size
        for (String ven : tempList) {
            String[] tmp = ven.split("@");
            arr[count] = Integer.parseInt(tmp[0]);
            log.info("arr[count]: " + arr[count]);
            count++;
        }
        int gcd = calculateGCD(arr,trottlingName);
        if(gcd==-1){
            log.info("GCD is -1");
            log.info("Configuration : "+trottlingName +" could not be added!!");
            throw new Exception();
        }
        int outOff = 0;
        for (int percent : arr) {
            outOff += percent / gcd;
        }
        log.info("Bucket Size is - " + outOff);

        // Needs to re-create at every time and will upsert into map
        Map<Integer, String> vendorStat = new TreeMap<Integer, String>();

        // calculate the waitage of each vendor
        int maxLimit = 0;
        for (String ven : tempList) {
            String[] tmp = ven.split("@");

            maxLimit = Integer.parseInt(tmp[0]) / gcd + maxLimit;
            log.info("maxLimit"+maxLimit);
            if(maxLimit ==100 && Integer.parseInt(tmp[0]) ==0){
                log.info("Adding 0% to : "+tmp[1]);
                vendorStat.put(0, tmp[1]);
            }
            else{
                vendorStat.put(maxLimit, tmp[1]);
            }
        }
        log.info("trottlingName"+trottlingName);
        log.info("vendorStat"+vendorStat);
        processorBucketedMap.put(trottlingName, vendorStat);
        // creating a token map for each throttling name.
        Token token = new Token(outOff);
        tokenMap.put(trottlingName, token);
        //}
		/*catch (Exception e) {
			e.printStackTrace();
			System.err.println("Configuration : "+trottlingName +" could not be added!!");
		}*/
    }
    int sum(int[] list) {
        int sum = 0;
        for (int i: list) {
            sum += i;
        }
        return sum;
    }
    int calculateGCD(int[] numbersArray, String trottlingName) {
        int gcd;
        // Added code
        //int sum = sum(numbersArray);

        int sum = sum(numbersArray);
        if (!(sum==100 | sum==10000)){
            log.info("sum of the percentage is not 100 for : "+ trottlingName + ". Sum is :"+sum);
            return -1;
        }

        if (numbersArray.length==1){
            gcd=1;
        }
        //Ends
        else{
            gcd = greatestCommonDivisor(numbersArray[0], numbersArray[1]);

            if (numbersArray.length > 2) {
                for (int y = 2; y < numbersArray.length; y++) {
                    gcd = greatestCommonDivisor(gcd, numbersArray[y]);
                }
            }
        }
        log.info("The greatest common divisor is " + gcd);
        return gcd;

    }

    static int greatestCommonDivisor(int m, int n) {
        int x;
        int y;
        if( m==0 || n==0){
            n=1;
        }
        else{
            while (m % n != 0) {
                x = n;
                y = m % n;
                m = x;
                n = y;
            }
        }
        return n;
    }

    public class Token {
     private int m_numWorkers = 1;
     private AtomicInteger m_counter = new AtomicInteger(0);

     Token(int numWorkers) {
         m_numWorkers = numWorkers;
     }

     public int next() {
         return m_counter.getAndIncrement() % m_numWorkers + 1;
     }
 }

 public Map<String, Map<Integer, String>> getProcessorMap()
 {
     return processorBucketedMap;
 }
 public Map<String, Token> getTokenMap()
 {
     return tokenMap;
 }


}
