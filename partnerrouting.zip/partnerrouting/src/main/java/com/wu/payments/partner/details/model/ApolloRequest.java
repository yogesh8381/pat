package com.wu.payments.partner.details.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Builder(toBuilder = true)
@Getter
@Setter
@ToString
public class ApolloRequest {

    public String country;
    public String currency;
    public String paymentType;
    public String paymentSubType;
    public String amount;
    public String paymentID;
    public String platform;
    public String partnerId;
}
