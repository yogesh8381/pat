package com.wu.payments.partner.details;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayinPartnerdetailsV1SvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayinPartnerdetailsV1SvcApplication.class, args);
	}

}
