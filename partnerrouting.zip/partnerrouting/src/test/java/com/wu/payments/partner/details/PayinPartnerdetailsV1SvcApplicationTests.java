package com.wu.payments.partner.details;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayinPartnerdetailsV1SvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
